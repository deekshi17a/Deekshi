<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explorica | About Us </title>

    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- custom css file in action -->

    <link rel="stylesheet" href="css/style.css">

    <!-- swipercss hain vro -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />

</head>

<body>
    <script src="js/script.js"></script>
    <!-- header section start -->

    <section class="header">
        <a href="home.php" class="logo">Explorica</a>

        <nav class="navbar">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="package.php">Packages</a>
            <a href="book.php" id="act3">Book</a>
            <a href="contactus.php">Contact Us</a>
        </nav>

        <div id="menu-btn" class="fas fa-bars"></div>
    </section>

    <!-- header section end -->

    <div class="heading" style="background:url(images/image1.jpg) no-repeat;">
        <h1>Book Now</h1>
    </div>

    <!-- booking section starts -->

    <section class="booking">

        <h1 class="heading-title">Book your trip!</h1>

        <form action="book_form.php" method="post" class="book-form" id="Form" onsubmit="return validateForm()">
    <div class="flex">
        <div class="inputBox">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" placeholder="Enter your name" required>
            <span class="error" id="nameError"></span>
        </div>
        <div class="inputBox">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" placeholder="Enter your email" required>
            <span class="error" id="emailError"></span>
        </div>
        <div class="inputBox">
            <label for="phone">Phone:</label>
            <input type="text" name="phone" id="phone" maxlength="10" placeholder="Enter your number" required>
            <span class="error" id="phoneError"></span>
        </div>
        <div class="inputBox">
            <label for="address">Address:</label>
            <input type="text" name="address" id="address" placeholder="Enter your address" required>
            <span class="error" id="addressError"></span>
        </div>
        <div class="inputBox">
            <label for="packages">Package:</label>
            <select name="packages" id="packages" required>
                <option value="">Select a package</option>
                <option value="Hampi">Hampi</option>
                <option value="Kuppali">Kuppali</option>
                <option value="Kabini Wildlife">Kabini Wildlife</option>
                <option value="Aihole">Aihole</option>
                <option value="Lalith mahal">Lalith mahal</option>
                <option value="Mysore Palace">Mysore Palace</option>
                <option value="Murdeshwara">Murdeshwara</option>
                <option value="Dandeli River">Dandeli River</option>
                <option value="Shivamogga">Shivamogga</option>
                <option value="Coorg">Coorg</option>
                <option value="Karwar">Karwar</option>
                <option value="Bangalore">Bangalore</option>
            </select>
            <span class="error" id="packageError"></span>
        </div>
        <div class="inputBox">
            <label for="guests">Guest count:</label>
            <input type="number" min="0" name="guests" id="guests" placeholder="Number of guests" required>
            <span class="error" id="guestsError"></span>
        </div>
        <div class="inputBox">
            <label for="arrivals">Date:</label>
            <input type="date" name="arrivals" id="arrivals" required>
            <span class="error" id="arrivalsError"></span>
        </div>
    </div>
    <input type="submit" value="Submit" class="btn" name="send">
</form>

    </section>

    <!-- booking section ends -->

    <!-- footer section starts -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> Home </a>
                <a href="about.php"><i class="fas fa-angle-right"></i> About </a>
                <a href="package.php"><i class="fas fa-angle-right"></i> Packages </a>
                <a href="book.php"><i class="fas fa-angle-right"></i> Book </a>
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i> Ask Questions </a>
                <a href="#"><i class="fas fa-angle-right"></i> About us </a>
                <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy </a>
                <a href="#"><i class="fas fa-angle-right"></i> Terms of use </a>
            </div>

            <div class="box">
                <h3>Contact-info</h3>
                <a href="#"><i class="fas fa-phone"></i> +91 7676819412 </a>
                <a href="#"><i class="fas fa-phone"></i> +91 9535224450 </a>
                <a href="#"><i class="fas fa-envelope"></i> explorica@gmail.com </a>
                <a href="#"><i class="fas fa-map"></i> Ujire, Karnataka </a>
            </div>

            <div class="box">
                <h3>Follow us</h3>
                <a href="#"><i class="fab fa-facebook"></i> Facebook </a>
                <a href="#"><i class="fab fa-twitter"></i> Twitter </a>
                <a href="#"><i class="fab fa-instagram"></i> Instagram </a>
                <a href="#"><i class="fab fa-linkedin"></i> Linkedin </a>
            </div>
        </div>

        <div class="credit">Passion-fueled creation by <span>Harsha</span> & <span>Deekshith</span>
        </div>

    </section>

    <!-- footersection ends -->

    <!-- swiper js link -->

    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

    <!-- custom js file vro -->

    <script src="js/script.js"></script>
</body>

</html>