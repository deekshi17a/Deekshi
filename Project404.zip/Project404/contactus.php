<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Explorica | Contact Us</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
  <!-- header section start -->

  <section class="header">

    <a href="home.php" class="logo">Explorica</a>

    <nav class="navbar">
      <a href="home.php">Home</a>
      <a href="about.php">About</a>
      <a href="package.php">Packages</a>
      <a href="book.php">Book</a>
      <a href="contactus.php" id="act4">Contact Us</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>
  </section>

  <div class="heading" style="background:url(images/image1.jpg) no-repeat;">
    <h1>Contact Us</h1>
  </div>

  <!-- header section end -->

  <section class="booking">
    <div class="container1">
      <div class="content1">
        <div class="left-side">
          <div class="address details">
            <i class="fas fa-map-marker-alt"></i>
            <div class="topic">Address</div>
            <div class="text-one">Ujire, Belthangady</div>
            <div class="text-two">D.K - 574240</div>
          </div>

          <div class="phone details">
            <i class="fas fa-phone-alt"></i>
            <div class="topic">Phone</div>
            <div class="text-one">+91 7676819412</div>
            <div class="text-two">+91 9535224450</div>
          </div>

          <div class="email details">
            <i class="fas fa-envelope"></i>
            <div class="topic">Email</div>
            <div class="text-one">explorica@gmail.com</div>
            <!-- <div class="text-two">deekshi@gmail.com</div> -->
          </div>

        </div>
        <div class="right-side">
          <div class="topic-text">Contact Us</div>
          <p class="para">If you have any questions or concerns, please don’t hesitate to contact us for further
            information.</p>
          <form action="https://api.web3forms.com/submit" method="POST" id="form">
            <input type="hidden" name="access_key" value="3d2f1845-4d6f-41d4-837b-a6bdf8f0a0bf">
            <div class="input-box">
              <input type="text" name="name" placeholder="Enter your name" required />
            </div>
            <div class="input-box">
              <input type="text" name="email" placeholder="Enter your email" required />
            </div>
            <div class="input-box message-box">
              <textarea name="message" placeholder="Enter your message"></textarea>
            </div>
            <div class="button">
              <input type="submit" class="button" value="Send Now" />
            </div>
            <input type="hidden" name="apikey" value="3d2f1845-4d6f-41d4-837b-a6bdf8f0a0bf">
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- footer section starts here -->

  <section class="footer">

    <div class="box-container">

      <div class="box">
        <h3>Quick links</h3>
        <a href="home.php"><i class="fas fa-angle-right"></i> Home </a>
        <a href="about.php"><i class="fas fa-angle-right"></i> About </a>
        <a href="package.php"><i class="fas fa-angle-right"></i> Packages </a>
        <a href="book.php"><i class="fas fa-angle-right"></i> Book </a>
      </div>

      <div class="box">
        <h3>Extra links</h3>
        <a href="#"><i class="fas fa-angle-right"></i> Contact Us</a>
        <a href="#"><i class="fas fa-angle-right"></i> About us </a>
        <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy </a>
        <a href="#"><i class="fas fa-angle-right"></i> Terms of use </a>
      </div>

      <div class="box">
        <h3>Contact-info</h3>
        <a href="#"><i class="fas fa-phone"></i> +91 7676819412 </a>
        <a href="#"><i class="fas fa-phone"></i> +91 9535224450 </a>
        <a href="#"><i class="fas fa-envelope"></i> explorica@gmail.com </a>
        <a href="#"><i class="fas fa-map"></i> Ujire, Karnataka </a>
      </div>

      <div class="box">
        <h3>Follow us</h3>
        <a href="#"><i class="fab fa-facebook"></i> Facebook </a>
        <a href="#"><i class="fab fa-twitter"></i> Twitter </a>
        <a href="#"><i class="fab fa-instagram"></i> Instagram </a>
        <a href="#"><i class="fab fa-linkedin"></i> Linkedin </a>
      </div>
    </div>

    <div class="credit">Passion-fueled creation by <span>Harsha</span> & <span>Deekshith</span>
    </div>

  </section>

  <!-- footersection ends -->

  <!-- custom js file vro -->
  <script src="js/script.js"></script>

</body>

</html>