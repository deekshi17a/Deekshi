<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explorica | Homepage</title>
    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- custom css file in action -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swipercss hain vro -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
    <!-- header section start -->
    <section class="header">
        <a href="home.php" class="logo">Explorica</a>
        <nav class="navbar">
            <a href="home.php" id="act">Home</a>
            <a href="about.php">About</a>
            <a href="package.php">Packages</a>
            <a href="book.php">Book</a>
            <a href="contactus.php">Contact Us</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars"></div>
    </section>
    <!-- header section end -->
    <!-- home section starts  -->
    <section class="home">
        <div class="swiper home-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide" style="background:url(images/malpe.jpeg) no-repeat">
                    <div class="content">
                        <span>Explore, Discover, Travel</span>
                        <h3>Travel around the world</h3>
                        <a href="package.php" class="btn">Discover More</a>
                    </div>
                </div>
                <div class="swiper-slide" style="background:url(images/jog.jpg) no-repeat">
                    <div class="content">
                        <span>Explore, Discover, Travel</span>
                        <h3>Travel around the world</h3>
                        <a href="package.php" class="btn">Discover More</a>
                    </div>
                </div>
                <div class="swiper-slide" style="background:url(images/dasara.jpg) no-repeat">
                    <div class="content">
                        <span>Explore, Discover, Travel</span>
                        <h3>Travel around the world</h3>
                        <a href="package.php" class="btn">Discover More</a>
                    </div>
                </div>
                <div class="swiper-slide" style="background:url(images/hawamahal.jpg) no-repeat">
                    <div class="content">
                        <span>Explore, Discover, Travel</span>
                        <h3>Travel around the world</h3>
                        <a href="package.php" class="btn">Discover More</a>
                    </div>
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </section>
    <!-- home section ends -->
    <!-- services section starts -->
    <section class="services">
        <h1 class="heading-title">Our services</h1>
        <div class="box-container">
            <div class="box">
                <img src="images/hiking1.png" alt="" srcset="">
                <h3>Adventures</h3>
            </div>
            <div class="box">
                <img src="images/tourguide.png" alt="" srcset="">
                <h3>Tour Guide</h3>
            </div>
            <div class="box">
                <img src="images/trekking.png" alt="" srcset="">
                <h3>Trekking</h3>
            </div>
            <div class="box">
                <img src="images/campfire.png" alt="" srcset="">
                <h3>Camp Fire</h3>
            </div>
            <div class="box">
                <img src="images/offroad.png" alt="" srcset="">
                <h3>Off-Road</h3>
            </div>
            <div class="box">
                <img src="images/camping1.png" alt="" srcset="">
                <h3>Camping</h3>
            </div>
        </div>
    </section>
    <!-- services section ends -->
    <!-- home about section starts -->
    <section class="home-about">

        <div class="image">
            <img src="images/about.jpg">
        </div>
        <div class="content">
            <h3>About us</h3>
            <p>Welcome to Explorica, your gateway to the wonders. We curate extraordinary adventures, revealing hidden
                gems, ancient heritage sites, and awe-inspiring landscapes. Unveil new chapters in your personal travel
                saga with Explorica.</p>
            <a href="about.php" class="btn">Read more</a>
        </div>

    </section>
    <!-- home about section ends -->

    <!-- home package section starts -->

    <section class="home-packages">

        <h1 class="heading-title"> Our Packages </h1>

        <div class="box-container">

            <div class="box">
                <div class="image">
                    <img src="images/dandeli.jpg" alt="">
                </div>
                <div class="content">
                    <h3> Adventures </h3>
                    <p>"Unleash Your Inner Explorer - Discover Thrilling Adventures!"</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/Hampi.jpg" alt="">
                </div>
                <div class="content">
                    <h3> Historical Moneuments </h3>
                    <p>"Unveil the Secrets of the Past - Explore Majestic Historic Monuments!"</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/lalith-mahal.jpg" alt="">
                </div>
                <div class="content">
                    <h3> Palaces </h3>
                    <p>"Step into Royal Grandeur - Experience the Majesty of Palaces!"</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

        </div>

        <div class="load-more"> <a href="package.php" class="btn">Load More</a> </div>

    </section>

    <!-- home package section ends -->

    <!-- home offer section start -->

    <section class="home-offer">
        <div class="content">
            <h3>Upto 50% off</h3>
            <p>"Unleash the Bargain Hunter in You - Up to 50% Off, It's Savings Galore!"</p>
            <a href="book.php" class="btn">Book Now</a>
        </div>
    </section>

    <!-- home offer section ends -->

    <!-- footer section starts -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> Home </a>
                <a href="about.php"><i class="fas fa-angle-right"></i> About </a>
                <a href="package.php"><i class="fas fa-angle-right"></i> Packages </a>
                <a href="book.php"><i class="fas fa-angle-right"></i> Book </a>
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="mail.php"><i class="fas fa-angle-right"></i> Contact Us</a>
                <a href="#"><i class="fas fa-angle-right"></i> About us </a>
                <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy </a>
                <a href="#"><i class="fas fa-angle-right"></i> Terms of use </a>
            </div>

            <div class="box">
                <h3>Contact-info</h3>
                <a href="#"><i class="fas fa-phone"></i> +91 7676819412 </a>
                <a href="#"><i class="fas fa-phone"></i> +91 9535224450 </a>
                <a href="#"><i class="fas fa-envelope"></i> explorica@gmail.com </a>
                <a href="#"><i class="fas fa-map"></i> Ujire, Karnataka </a>
            </div>

            <div class="box">
                <h3>Follow us</h3>
                <a href="#"><i class="fab fa-facebook"></i> Facebook </a>
                <a href="#"><i class="fab fa-twitter"></i> Twitter </a>
                <a href="#"><i class="fab fa-instagram"></i> Instagram </a>
                <a href="#"><i class="fab fa-linkedin"></i> Linkedin </a>
            </div>
        </div>

        <div class="credit">Passion-fueled creation by <span>Harsha</span> & <span>Deekshith</span>
        </div>

    </section>
    <!-- footersection ends -->
    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <!-- custom js file vro -->
    <script src="js/script.js"></script>
</body>

</html>