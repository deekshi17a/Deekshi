// Select DOM elements
const menuBtn = document.querySelector("#menu-btn");
const navbar = document.querySelector(".header .navbar");

// Toggle navbar on click
menuBtn.addEventListener("click", () => {
  menuBtn.classList.toggle("fa-times");
  navbar.classList.toggle("active");
});

// Hide navbar on scroll
window.addEventListener("scroll", () => {
  menuBtn.classList.remove("fa-times");
  navbar.classList.remove("active");
});

// Initialize home slider
const homeSlider = new Swiper(".home-slider", {
  loop: true,
  autoplay: {
    delay: 3000, // Time between each slide transition in milliseconds
    disableOnInteraction: false, // Set to true if you want autoplay to be disabled when user interacts with the slider
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

// Initialize reviews slider
const reviewsSlider = new Swiper(".reviews-slider", {
  loop: true,
  spaceBetween: 20,
  autoHeight: true,
  grabCursor: true,
  autoplay: {
    delay: 2000, // Time between each slide transition in milliseconds
    disableOnInteraction: false, // Set to true if you want autoplay to be disabled when user interacts with the slider
  },
  breakpoints: {
    640: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});

// Load more packages on button click
const loadMoreBtn = document.querySelector(".packages .load-more .btn");
let currentItem = 3;

loadMoreBtn.addEventListener("click", () => {
  const boxes = document.querySelectorAll(".packages .box-container .box");
  for (let i = currentItem; i < currentItem + 3; i++) {
    boxes[i].style.display = "inline-block";
  }
  currentItem += 3;
  if (currentItem >= boxes.length) {
    loadMoreBtn.style.display = "none";
  }
});

function validateForm() {
  // Clear previous error messages
  clearErrors();

  // Get form input values
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var address = document.getElementById("address").value;
  var package = document.getElementById("packages").value;
  var guests = document.getElementById("guests").value;
  var arrivals = document.getElementById("arrivals").value;

  // Validate name field
  if (name === "") {
    displayError("nameError", "Please enter your name");
    return false;
  }

  // Validate email field
  if (email === "") {
    displayError("emailError", "Please enter your email");
    return false;
  }

  // Validate phone field
  if (phone === "") {
    displayError("phoneError", "Please enter your phone number");
    return false;
  } else if (!/^\d{10}$/.test(phone)) {
    displayError("phoneError", "Please enter a valid 10-digit phone number");
    return false;
  }

  // Validate address field
  if (address === "") {
    displayError("addressError", "Please enter your address");
    return false;
  }

  // Validate package field
  if (package === "") {
    displayError("packageError", "Please select a package");
    return false;
  }

  // Validate guests field
  if (guests === "") {
    displayError("guestsError", "Please enter the number of guests");
    return false;
  }

  // Validate arrivals field
  if (arrivals === "") {
    displayError("arrivalsError", "Please enter the date of arrival");
    return false;
  }

  return true; // Submit the form
}

function displayError(elementId, errorMessage) {
  var errorElement = document.getElementById(elementId);
  errorElement.innerHTML = errorMessage;
}

function clearErrors() {
  var errorElements = document.getElementsByClassName("error");
  for (var i = 0; i < errorElements.length; i++) {
    errorElements[i].innerHTML = "";
  }
}
