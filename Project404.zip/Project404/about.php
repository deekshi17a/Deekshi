<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explorica | About Us </title>
    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- custom css file in action -->

    <link rel="stylesheet" href="css/style.css">

    <!-- swipercss hain vro -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
    <!-- header section start -->

    <section class="header">
        <a href="home.php" class="logo">Explorica</a>

        <nav class="navbar">
            <a href="home.php">Home</a>
            <a href="about.php" id="act1">About</a>
            <a href="package.php">Packages</a>
            <a href="book.php">Book</a>
            <a href="contactus.php">Contact Us</a>
        </nav>

        <div id="menu-btn" class="fas fa-bars"></div>
    </section>

    <!-- header section end -->

    <div class="heading" style="background:url(images/image1.jpg) no-repeat;">
        <h1>about us</h1>
    </div>

    <!-- about section starts -->

    <section class="about">
        <div class="image">
            <img src="images/about.jpg" alt="">
        </div>

        <div class="content">
            <h3>Why choose us?</h3>
            <p>At Explorica, we pride ourselves on providing exceptional travel experiences with the help of our
                experienced tour directors. Our dedicated team ensures that every aspect of your trip, from
                transportation to accommodations to sightseeing, runs seamlessly. With safety as our top priority, we
                take extensive measures to ensure a secure and enjoyable experience for all travelers. Whether you're
                interested in an immersive language immersion program, a cultural exchange, or a service-learning
                project, we have the expertise and resources to create a transformative travel experience. Embark on a
                journey of discovery and exploration with us and be prepared for an unforgettable adventure!
            <div class="icons-container">
                <div class="icons">
                    <i class="fas fa-map"></i>
                    <span>Top destinations</span>
                </div>
                <div class="icons">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Affordable price</span>
                </div>
                <div class="icons">
                    <i class="fas fa-headset"></i>
                    <span>24/7 Guide Service</span>
                </div>
            </div>
        </div>
    </section>

    <!-- about section ends -->

    <!-- reviews section starts -->

    <section class="reviews">

        <h1 class="heading-title"> client reviews </h1>

        <div class="swiper reviews-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Booking was a breeze! The website's clean interface made it easy to find and compare
                        destinations. Detailed info on attractions and accommodations. Customer support was responsive
                        and helpful. Fantastic experience!"</p>
                    <h3>Ganesh</h3>
                    <span>Traveler</span>
                    <img src="images/avatar1.png" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Can't recommend enough! My go-to for planning vacations. Wide range of options, from budget to
                        luxury. Comprehensive travel guides with insider tips. Seamless bookings and unforgettable
                        adventures. Love it!"</p>
                    <h3>Kiran Kumar</h3>
                    <span>Traveler</span>
                    <img src="images/avatar2.png" alt="">
                </div>

                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Exceeded expectations! Visually appealing interface for adventure seekers. Vast selection of
                        tours and packages. Straightforward booking process. Had an incredible time! Highly
                        recommended."</p>
                    <h3>Dhanush</h3>
                    <span>Traveler</span>
                    <img src="images/avatar3.png" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Huge success for our family vacation! Stress-free planning with detailed info on family-friendly
                        destinations and activities. Suitable accommodations and great customer service. Can't wait for
                        the next getaway!"</p>
                    <h3>Karthik</h3>
                    <span>Traveler</span>
                    <img src="images/avatar4.png" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Game-changer for solo travel! Wide range of options and solo-friendly accommodations. Valuable
                        community forum for connecting with other travelers. Emphasis on safety and local customs.
                        Incredible solo adventures!"</p>
                    <h3>Dinesh</h3>
                    <span>Traveler</span>
                    <img src="images/avatar5.png" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"This online tourism website is a game-changer for travelers like me. Sleek design, seamless
                        experience. Loved the personalized recommendations and competitive prices. Can't wait to use it
                        again for my next adventure!"</p>
                    <h3>Samarth</h3>
                    <span>Traveler</span>
                    <img src="images/avatar6.png" alt="">
                </div>
            </div>
        </div>
    </section>
    <!-- reviews section ends -->

    <!-- footer section starts -->
    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> Home </a>
                <a href="about.php"><i class="fas fa-angle-right"></i> About </a>
                <a href="package.php"><i class="fas fa-angle-right"></i> Packages </a>
                <a href="book.php"><i class="fas fa-angle-right"></i> Book </a>
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i> Ask Questions </a>
                <a href="#"><i class="fas fa-angle-right"></i> About us </a>
                <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy </a>
                <a href="#"><i class="fas fa-angle-right"></i> Terms of use </a>
            </div>

            <div class="box">
                <h3>Contact-info</h3>
                <a href="#"><i class="fas fa-phone"></i> +91 7676819412 </a>
                <a href="#"><i class="fas fa-phone"></i> +91 9535224450 </a>
                <a href="#"><i class="fas fa-envelope"></i>  explorica@gmail.com </a>
                <a href="#"><i class="fas fa-map"></i> Ujire, Karnataka </a>
            </div>

            <div class="box">
                <h3>Follow us</h3>
                <a href="#"><i class="fab fa-facebook"></i> Facebook </a>
                <a href="#"><i class="fab fa-twitter"></i> Twitter </a>
                <a href="#"><i class="fab fa-instagram"></i> Instagram </a>
                <a href="#"><i class="fab fa-linkedin"></i> Linkedin </a>
            </div>
        </div>

        <div class="credit">Passion-fueled creation by <span>Harsha</span> & <span>Deekshith</span></div>

    </section>

    <!-- footersection ends -->

    <!-- swiper js link -->

    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

    <!-- custom js file vro -->

    <script src="js/script.js"></script>
</body>

</html>