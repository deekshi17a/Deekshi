<?php
// Get the email from the form submission
$email = $_POST['email'];

// Generate a random OTP
$otp = mt_rand(100000, 999999);

// Store the OTP in the database along with the email
// Note: Make sure you have a table named "users" with columns for email and otp
$conn = new mysqli("localhost", "username", "password", "database_name");
$stmt = $conn->prepare("INSERT INTO users (email, otp) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();

// Send the OTP via email
$to = $email;
$subject = "Verification OTP";
$message = "Your OTP is: " . $otp;
$headers = "From: your_email@example.com"; // Replace with your email address
mail($to, $subject, $message, $headers);

echo "An OTP has been sent to your email address.";
?>
