<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explorica | About Us </title>
    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- custom css file in action -->
    <link rel="stylesheet" href="css/style.css">
    <!-- swipercss hain vro -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
    <!-- header section start -->
    <section class="header">
        <a href="home.php" class="logo">Explorica</a>
        <nav class="navbar">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="package.php" id="act2">Packages</a>
            <a href="book.php">Book</a>
            <a href="contactus.php">Contact Us</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars"></div>
    </section>
    <!-- header section end -->
    <div class="heading" style="background:url(images/image1.jpg) no-repeat;">
        <h1>Packages</h1>
    </div>
    <section class="packages">
        <h1 class="heading-title"> top Destination </h1>
        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="images/Hampi.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Hampi</h3>
                    <p>Hampi, a historic village in Karnataka, houses captivating ruins of temple complexes from the
                        Vijayanagara Empire, showcasing the grandeur of the bygone era.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/Kuppali.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Kuppali</h3>
                    <p>Kuppali, a serene village in Karnataka's Shimoga district, holds significance as the cherished
                        birthplace of Kuvempu, the acclaimed Kannada poet, evoking literary inspiration and nostalgia.
                    </p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/Kabini.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Kabini Wildlife</h3>
                    <p>Embark on the captivating Kabini Backwaters Forest Safari, a renowned experience led by the
                        Karnataka Forest Department along the picturesque Kabini river, offering thrilling encounters
                        with nature's wonders.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/Aihole.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Aihole</h3>
                    <p>Aihole, a treasure trove of ancient heritage in Karnataka, India, unveils a remarkable tapestry
                        of Buddhist, Hindu, and Jain monuments spanning from the 6th to 12th century CE, capturing the
                        essence of diverse cultural influences through time.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/lalith-mahal.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Lalith mahal</h3>
                    <p>Lalitha Mahal, an opulent palace-turned-hotel in Mysore, Karnataka, exudes regal charm near the
                        majestic Chamundi Hills. Constructed by Maharaja Krishnaraja Wodeyar IV in 1921, it offers a
                        luxurious retreat for discerning guests.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/mysore.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Mysore Palace</h3>
                    <p>Mysore Palace, the grand Amba Vilas Palace, stands as a historic symbol of royalty in Mysore,
                        Karnataka, India. Once the regal abode of the Wadiyar dynasty, it mesmerizes visitors with its
                        architectural splendor and rich heritage.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/murdeshwara.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Murdeshwara</h3>
                    <p>Murdeshwar, a coastal town in Karnataka's Uttara Kannada district, beckons with the world's
                        second tallest Shiva statue and the revered Murudeshwara Temple. Nestled along the Arabian Sea,
                        it presents a captivating blend of natural beauty and religious significance.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/dandeli.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Dandeli River</h3>
                    <p>Dandeli, a scenic town in Karnataka, is blessed with the captivating Dandeli Wildlife Sanctuary.
                        Nestled amidst dense forests, it offers a haven for diverse wildlife, including black panthers,
                        elephants, and an array of enchanting bird species.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/jog.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Jog Falls</h3>
                    <p>Jog Falls, nestled in the Shimoga district of Karnataka, graces the Western Ghats with its
                        majestic beauty. As India's third highest plunge waterfall, it mesmerizes with its breathtaking
                        cascade along the Sharavati river.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/coorg.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Coorg</h3>
                    <p>Nestled in misty mountains, this enchanting coffee-producing hill station allures with its lush
                        green hills and meandering streams. Immerse yourself in the rich culture and warm hospitality of
                        the Kodavas, a martial arts-specializing local clan.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/karwar.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Karwar</h3>
                    <p>Experience the multicultural charm of Karwar, where historic monuments meet stunning landscapes.
                        Dive into thrilling adventures like snorkeling, scuba diving, and surfing in this photographer's
                        paradise.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/banglore.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bangalore</h3>
                    <p>From Garden City to Silicon Valley, India's third-largest city enchants with its delightful
                        weather, scenic parks, and picturesque lakes. Indulge in a culinary adventure with a vibrant
                        food scene offering everything from street food to international cuisines, making Bangalore a
                        gastronomic haven.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
        </div>
        <div class="load-more"><span class="btn">Load More</span></div>
    </section>
    <!-- footer section starts -->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> Home </a>
                <a href="about.php"><i class="fas fa-angle-right"></i> About </a>
                <a href="package.php"><i class="fas fa-angle-right"></i> Packages </a>
                <a href="book.php"><i class="fas fa-angle-right"></i> Book </a>
            </div>
            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i> Ask Questions </a>
                <a href="#"><i class="fas fa-angle-right"></i> About us </a>
                <a href="#"><i class="fas fa-angle-right"></i> Privacy Policy </a>
                <a href="#"><i class="fas fa-angle-right"></i> Terms of use </a>
            </div>
            <div class="box">
                <h3>Contact-info</h3>
                <a href="#"><i class="fas fa-phone"></i> +91 7676819412 </a>
                <a href="#"><i class="fas fa-phone"></i> +91 9535224450 </a>
                <a href="#"><i class="fas fa-envelope"></i> explorica@gmail.com </a>
                <a href="#"><i class="fas fa-map"></i> Ujire, Karnataka </a>
            </div>
            <div class="box">
                <h3>Follow us</h3>
                <a href="#"><i class="fab fa-facebook"></i> Facebook </a>
                <a href="#"><i class="fab fa-twitter"></i> Twitter </a>
                <a href="#"><i class="fab fa-instagram"></i> Instagram </a>
                <a href="#"><i class="fab fa-linkedin"></i> Linkedin </a>
            </div>
        </div>
        <div class="credit">Passion-fueled creation by <span>Harsha</span> & <span>Deekshith</span></div>
    </section>
    <!-- footersection ends -->
    <!-- swiper js link -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <!-- custom js file vro -->
    <script src="js/script.js"></script>
</body>

</html>